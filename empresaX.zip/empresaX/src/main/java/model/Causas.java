package model;

public class Causas {
	private String IdCausa;
	private String Tipo;
	
	public Causas(String idCausa, String tipo) {
		super();
		IdCausa = idCausa;
		Tipo = tipo;
	}

	public String getIdCausa() {
		return IdCausa;
	}

	public void setIdCausa(String idCausa) {
		IdCausa = idCausa;
	}

	public String getTipo() {
		return Tipo;
	}

	public void setTipo(String tipo) {
		Tipo = tipo;
	}
	
	

}
